//
//  SwiftUIView.swift
//  BitBuggyShop
//
//  Created by Emily Combs on 4/25/24.
//

import SwiftUI

struct SwiftUIView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    SwiftUIView()
}
