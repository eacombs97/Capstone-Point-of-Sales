/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.POS;
import java.util.List;
import java.util.ArrayList;
/**
 *
 * @author kairagaines
 */
public class OrderItem {
    private Product  product;
    private int quantity;
    
    private double subtotal; 

    
    public OrderItem(Product product, int quantity) {
        this.product = product;
        this.quantity = quantity;
    }
    /**
     * @return the productID
     */
    public Product getProduct() {
        return product;
    }

    /**
     * @param productID the productID to set
     */
    public void setProduct(Product productID) {
        this.product = productID;
    }

    /**
     * @return the quantity
     */
    public int getQuantity() {
        return quantity;
    }

    /**
     * @param quantity the quantity to set
     */
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    /**
     * @return the subtotal
     */
    public double getSubtotal() {
        //if product id do... get unit price
        
          return product.getPrice() *quantity;
         
    }

    /**
     * @param subtotal the subtotal to set
     */
    public void setSubtotal(float subtotal) {
        this.subtotal = subtotal;
    }
    
    @Override
    public String toString(){
        return String.format("Product: %s%nQuantity: %d%nSubtotal: $%.2f%n ",product, quantity, subtotal);
    }
    
}
class Product {
    private static List<Product> productList = new ArrayList<>();
    private String productId;
    private String name;
    private double price;
    private String description;
    // Other attributes...

    // Constructor
    public Product(String productId, String name, double price, String description) {
        this.productId = productId;
        this.name = name;
        this.price = price;
        this.description = description;
    }

    // Getter and setter methods for productId
    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    // Getter and setter methods for name
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    // Getter and setter methods for price
    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    // Getter and setter methods for description
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    // Add a product to the list
    public void addProduct(Product product) {
        productList.add(product);
    }

    // Get the list of products
    public static List<Product> getProductList() {
        return productList;
    }
    @Override 
    public String toString(){
        return String.format("%s %s $%.2f %s",productId,name,price,description);
    }
}


