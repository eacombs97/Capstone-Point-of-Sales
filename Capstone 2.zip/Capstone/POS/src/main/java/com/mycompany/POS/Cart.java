/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.POS;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author kairagaines
 */
public class Cart {
 private ArrayList<OrderItem> items= new ArrayList<>();
// private double price;

 public void addToCart(OrderItem item, int quantity){
 
     
     items.add(new OrderItem(item.getProduct(), quantity));
 }
 
 public void removeFromCart(OrderItem item, int quantity){
     items.remove(item);
   
 }
 
    
  
 
 
 /**
     * @return the orderItem
     */
    public ArrayList<OrderItem> getOrderItem() {
        return items;
    }

    /**
     * @param orderItem the orderItem to set
     */
  /*  public void setOrderItem(ArrayList<OrderItem> orderItem) {
        this.orderItem = orderItem;
    }


    /**
     * @param subtotal the subtotal to set
     */
    public double calculateSubtotal() {
        double total =   0;
        for(OrderItem item: items){
            total+=item.getSubtotal();
        }
     return total;
    }
 
    //display item and price method
    public void displayItem(){
      
    for (OrderItem item: items){
        
        System.out.print(item);
    
    }
    }
         
    
    public void checkOut(){
        //take cart, shipping, display, payment info
        displayCart();
        getShippingInfo();
        getPaymentInfo();
        
        
    }
    public void displayCart(){
        for (OrderItem item: items){
            System.out.println(item);
        }
    } 
    public void getShippingInfo(){
        Scanner input = new Scanner(System.in);
        //prompt for shipping 
    }
    public void getPaymentInfo(){
        
    }
}
