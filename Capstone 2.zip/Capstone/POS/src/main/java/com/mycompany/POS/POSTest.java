/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.POS;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class POSTest extends JFrame {

    private JPanel currentPanel;
    private JPanel landingPanel;

    public POSTest() {
        setTitle("BitBuggy");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null); // Center the window on the screen

        // Create main landing page panel
        landingPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.fill = GridBagConstraints.BOTH;

        // Create product images panel
        JPanel productPanel = new JPanel(new GridLayout(2, 3, 10, 10));
        productPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Sample product images (replace with your own)
        ImageIcon product1Image = new ImageIcon("product1.jpg");
        ImageIcon product2Image = new ImageIcon("product2.jpg");
        ImageIcon product3Image = new ImageIcon("product3.jpg");
        ImageIcon product4Image = new ImageIcon("product4.jpg");
        ImageIcon product5Image = new ImageIcon("product5.jpg");
        ImageIcon product6Image = new ImageIcon("product6.jpg");

        JLabel product1Label = new JLabel(product1Image);
        JLabel product2Label = new JLabel(product2Image);
        JLabel product3Label = new JLabel(product3Image);
        JLabel product4Label = new JLabel(product4Image);
        JLabel product5Label = new JLabel(product5Image);
        JLabel product6Label = new JLabel(product6Image);

        productPanel.add(product1Label);
        productPanel.add(product2Label);
        productPanel.add(product3Label);
        productPanel.add(product4Label);
        productPanel.add(product5Label);
        productPanel.add(product6Label);

        // Create navigation panel with buttons
        JPanel navigationPanel = new JPanel(new GridLayout(2, 1, 10, 10));
        navigationPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        JButton viewCartButton = new JButton("View Cart", new ImageIcon("view_cart_icon.png"));
        JButton checkoutButton = new JButton("Checkout", new ImageIcon("checkout_icon.png"));

        viewCartButton.setVerticalTextPosition(SwingConstants.BOTTOM);
        viewCartButton.setHorizontalTextPosition(SwingConstants.CENTER);
        checkoutButton.setVerticalTextPosition(SwingConstants.BOTTOM);
        checkoutButton.setHorizontalTextPosition(SwingConstants.CENTER);

        viewCartButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showCartPage();
            }
        });

        checkoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showCheckoutPage();
            }
        });

        navigationPanel.add(viewCartButton);
        navigationPanel.add(checkoutButton);

        // Add product images panel and navigation panel to landing panel
        gbc.weightx = 0.7;
        gbc.gridy = 0;
        landingPanel.add(productPanel, gbc);
        gbc.weightx = 0.3;
        gbc.gridy = 0;
        gbc.gridx = 1;
        landingPanel.add(navigationPanel, gbc);

        // Set landing page as the current panel
        currentPanel = landingPanel;
        getContentPane().add(currentPanel);

        setVisible(true);
    }

    private void showCartPage() {
        // Logic for showing the cart page
        JOptionPane.showMessageDialog(this, "View Cart Page");
    }

    private void showCheckoutPage() {
        // Logic for showing the checkout page
        JOptionPane.showMessageDialog(this, "Checkout Page");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new POSTest());
    }
}
