package com.pos.pointofsaleswebapp.repositories;

import com.pos.pointofsaleswebapp.model.Order;

public interface OrderDAO {
    void saveOrder(Order order);
}




