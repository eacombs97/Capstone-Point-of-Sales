package com.pos.pointofsaleswebapp.controllers;

//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;


import com.pos.pointofsaleswebapp.model.Customer;
import com.pos.pointofsaleswebapp.model.Order;
//import com.pos.pointofsaleswebapp.services.OrderService;

import jakarta.servlet.http.HttpSession;

import java.util.*;

@Controller
@RequestMapping("/order")
public class OrderController {

    
    
    
    @GetMapping("/confirmation")
    public String showOrderConfirmation(Model model, HttpSession session) {
        // Add necessary model attributes
        Customer customer = (Customer) session.getAttribute("customer");
        String confirmationNumber= generateConfirmationNumber();
        // Retrieve order object from session
        Order order = (Order) session.getAttribute("order");
        model.addAttribute("customer", customer);
        model.addAttribute("order", order);
        model.addAttribute("confirmationNumber", confirmationNumber);
        return "confirmation"; // Make sure this matches the template file name
    }
  
    
    private String generateConfirmationNumber() {
        Random random = new Random();
        int min = 100000; // Minimum 6-digit number
        int max = 999999; // Maximum 6-digit number
        int randomNumber = random.nextInt(max - min + 1) + min;
        return String.valueOf(randomNumber);
    }
 
}



