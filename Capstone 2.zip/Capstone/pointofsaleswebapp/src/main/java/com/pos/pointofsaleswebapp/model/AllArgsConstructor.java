package com.pos.pointofsaleswebapp.model;

public @interface AllArgsConstructor {

}
