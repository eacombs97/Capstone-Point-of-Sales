package com.pos.pointofsaleswebapp.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.pos.pointofsaleswebapp.model.Customer;
import com.pos.pointofsaleswebapp.model.Order;
import com.pos.pointofsaleswebapp.model.OrderItem;

import jakarta.servlet.http.HttpSession;
@Service
public class OrderService {

    public Order createOrder(Order orderDetails, HttpSession session) {
        Customer customer = (Customer) session.getAttribute("customer");
        if (customer == null) {
            throw new IllegalArgumentException("Customer is null");
        }
        if (orderDetails == null) {
            throw new IllegalArgumentException("Order details are null");
        }
        List<OrderItem> orderItems = orderDetails.getCart();
        double totalPrice = calculateTotalPrice(orderItems);
        String customerId = customer.getCustomerId();
        String orderId = orderDetails.getOrderId();
        if (orderItems.isEmpty()) {
            throw new IllegalArgumentException("Cart is empty");
        }
        return new Order(customerId, orderId, orderItems, totalPrice);
    }
    

    private double calculateTotalPrice(List<OrderItem> orderItems) {
        double totalPrice = 0.0;
        for (OrderItem item : orderItems) {
            double productPrice = item.getProduct().getPrice();
            totalPrice+= productPrice * item.getQuantity();
        }
        return totalPrice;
    }
}
